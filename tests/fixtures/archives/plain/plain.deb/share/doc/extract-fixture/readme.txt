fixture payload A
